import json
import boto3
import os
import time
from datetime import datetime
import uuid

def lambda_handler(event, context):
    try:
        # Initialize AWS clients
        s3_client = boto3.client('s3')
        dynamodb = boto3.resource('dynamodb')
        table_name = os.environ['DYNAMODB_TABLE_NAME']
        table = dynamodb.Table(table_name)
        
        # Process S3 event
        for record in event['Records']:
            # Extract S3 information
            s3_bucket = record['s3']['bucket']['name']
            s3_key = record['s3']['object']['key']
            s3_size = record['s3']['object']['size']
            s3_event_time = record['eventTime']
            
            # Generate unique fileId
            file_id = str(uuid.uuid4())
            
            # Determine file type from extension
            file_extension = os.path.splitext(s3_key)[1].lower()
            file_type = file_extension if file_extension else 'unknown'
            
            # Create item for DynamoDB
            item = {
                'fileId': file_id,
                'filename': s3_key,
                'bucket': s3_bucket,
                'fileSize': s3_size,
                'fileType': file_type,
                'status': 'pending',  # Initial status
                'createdTimestamp': s3_event_time,
                'updatedTimestamp': s3_event_time,
                'uploadedBy': 's3_trigger',
                'metadata': {
                    'source': 's3_upload',
                    'event_type': record['eventName']
                }
            }
            
            # Insert into DynamoDB
            table.put_item(Item=item)
            
            print(f"Successfully inserted file record: {file_id} for file: {s3_key}")
            
            # Start polling for GuardDuty tags
            poll_guardduty_tags(s3_client, s3_bucket, s3_key, file_id, table)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully processed S3 upload event',
                'processed_files': len(event['Records'])
            })
        }
        
    except Exception as e:
        print(f"Error processing S3 event: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def poll_guardduty_tags(s3_client, bucket, key, file_id, table):
    """
    Poll for GuardDuty tags every 1 second for 10 times
    """
    max_attempts = 10
    poll_interval = 1  # 1 second
    
    print(f"Starting to poll for GuardDuty tags for file: {key}")
    
    for attempt in range(max_attempts):
        try:
            print(f"Polling attempt {attempt + 1}/{max_attempts}")
            
            # Get object tags
            response = s3_client.get_object_tagging(
                Bucket=bucket,
                Key=key
            )
            
            # Check for GuardDutyMalwareScanStatus tag
            guardduty_status = None
            for tag in response.get('TagSet', []):
                if tag['Key'] == 'GuardDutyMalwareScanStatus':
                    guardduty_status = tag['Value']
                    break
            
            if guardduty_status:
                print(f"Found GuardDuty tag: {guardduty_status}")
                update_status(table, file_id, guardduty_status)
                
                # If threats found, move object to malware bucket
                if guardduty_status == 'THREATS_FOUND':
                    move_to_malware_bucket(s3_client, bucket, key, file_id, table)
                
                return
            else:
                print(f"No GuardDuty tag found on attempt {attempt + 1}")
                
                # Update status to indicate polling is in progress
                if attempt == 0:
                    update_status(table, file_id, 'scanning')
                
        except Exception as e:
            print(f"Error polling for tags on attempt {attempt + 1}: {str(e)}")
        
        # Wait before next attempt (except on last attempt)
        if attempt < max_attempts - 1:
            time.sleep(poll_interval)
    
    # If no tag found after all attempts, set status to FAILED
    print(f"No GuardDuty tag found after {max_attempts} attempts")
    update_status(table, file_id, 'FAILED')

def update_status(table, file_id, status):
    """
    Update status in DynamoDB
    """
    try:
        table.update_item(
            Key={'fileId': file_id},
            UpdateExpression='SET status = :status, updatedTimestamp = :timestamp',
            ExpressionAttributeValues={
                ':status': status,
                ':timestamp': datetime.utcnow().isoformat()
            }
        )
        print(f"Updated status for {file_id}: {status}")
    except Exception as e:
        print(f"Error updating status: {str(e)}")

def move_to_malware_bucket(s3_client, source_bucket, source_key, file_id, table):
    """
    Move object from unscanned bucket to malware bucket
    """
    try:
        malware_bucket = f"{source_bucket}-malware-objects"
        
        print(f"Moving {source_key} from {source_bucket} to {malware_bucket}")
        
        # Copy object to malware bucket
        copy_source = {
            'Bucket': source_bucket,
            'Key': source_key
        }
        
        s3_client.copy_object(
            CopySource=copy_source,
            Bucket=malware_bucket,
            Key=source_key
        )
        
        # Delete object from original bucket
        s3_client.delete_object(
            Bucket=source_bucket,
            Key=source_key
        )
        
        # Update DynamoDB with new bucket location
        table.update_item(
            Key={'fileId': file_id},
            UpdateExpression='SET bucket = :bucket, status = :status, updatedTimestamp = :timestamp',
            ExpressionAttributeValues={
                ':bucket': malware_bucket,
                ':status': 'MOVED_TO_MALWARE_BUCKET',
                ':timestamp': datetime.utcnow().isoformat()
            }
        )
        
        print(f"Successfully moved {source_key} to malware bucket")
        
    except Exception as e:
        print(f"Error moving object to malware bucket: {str(e)}")
        # Update status to indicate move failed
        update_status(table, file_id, 'MOVE_FAILED') 